#!/bin/bash
for port in {50001..50010}; do
    base_dir="/var/www/html/RW-HPS-master/${port}/StartServer/data"
    for file in RelayConfig.json ConfigServer.json Config.json; do
        if [ -f "${base_dir}/${file}" ]; then
            echo "文件存在: ${base_dir}/${file}"
            chmod 0777 "${base_dir}/${file}"
        else
            echo "文件不存在: ${base_dir}/${file}"
        fi
    done
done